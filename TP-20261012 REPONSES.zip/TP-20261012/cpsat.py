from ortools.sat.python import cp_model

# Données
horizon = 11
noms = ["Urban", "Cargo", "Sport"]
dur = [3, 5, 4]

# Création du modèle
model = cp_model.CpModel()

starts = []
ends = []
intervals = []

# Création des intervalles
for i in range(3):
    s = model.new_int_var(0, horizon, f"start_{noms[i]}")
    e = model.new_int_var(0, horizon, f"end_{noms[i]}")

    interval = model.new_interval_var(
        s, dur[i], e, f"interval_{noms[i]}"
    )

    starts.append(s)
    ends.append(e)
    intervals.append(interval)

# Aucun chevauchement entre les lots
model.add_no_overlap(intervals)

# Minimiser le makespan
makespan = model.new_int_var(0, horizon, "makespan")
model.add_max_equality(makespan, ends)
model.minimize(makespan)

# Résolution
solver = cp_model.CpSolver()
status = solver.solve(model)

if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    for i in range(3):
        print(
            f"{noms[i]} : début={solver.value(starts[i])}h, "
            f"fin={solver.value(ends[i])}h"
        )
    print(f"Makespan = {solver.value(makespan)}h")
else:
    print("Aucune solution trouvée.")